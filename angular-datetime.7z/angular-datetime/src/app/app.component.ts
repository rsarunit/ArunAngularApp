import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  showPicker = false;
  myDate: Date = new Date();
  showDate = true;
  showTime = true;
  closeButton: any = { show: true, label: 'Close Me!', cssClass: 'btn btn-sm btn-primary' };

  onTogglePicker() {
      if (this.showPicker === false) {
          this.showPicker = true;
      }
  }

  onValueChange(val: Date) {
      this.myDate = val;
  }

  isValid(): boolean {
    console.log(this.myDate);
    // this function is only here to stop the datepipe from erroring if someone types in value
      return this.myDate && (typeof this.myDate !== 'string') && !isNaN(this.myDate.getTime());
     
    }
}
