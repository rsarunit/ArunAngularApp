import { ArunAppPage } from './app.po';

describe('arun-app App', () => {
  let page: ArunAppPage;

  beforeEach(() => {
    page = new ArunAppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
