import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';

import {LoginModule} from './modules/login/login.module';
import {HomeModule} from './modules/home/home.module';
import {LoginRoutingModule} from './modules/login/login-routing.module';
import {HomeRoutingModule} from './modules/home/home-routing.module';
import{AppRoutingModule} from './app-routing.module';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    LoginModule,
    HomeModule,
    LoginRoutingModule,
    HomeRoutingModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
