import {Component} from '@angular/core';

@Component({
  template:`<div class="container">
      <h1>Login to e-payingguest</h1>
      <form>
        <div class="form-group">
          <label for="username">Name</label>
          <input type="text" class="form-control"  name="username" id="username"  required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-control"  name="password" id="password">
        </div>
        <button type="submit" class="btn btn-success">Submit</button>
      </form>
  </div>
`
})
export class LoginComponent{

}
