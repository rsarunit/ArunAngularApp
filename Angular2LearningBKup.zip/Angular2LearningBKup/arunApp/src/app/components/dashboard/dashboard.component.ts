import { Component, OnInit } from '@angular/core';

@Component({
  template: `<h1 style="margin-top:50px;">Showing Dashboard</h1>`,

})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
