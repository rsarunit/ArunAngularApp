import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';

// application module imports
import { UnAuthflowsModule } from './un-authflows/un-authflows.module';
import { UnAuthflowsRoutingModule } from './un-authflows/un-authflows-routing.module';
import { AuthflowsModule } from './authflows/authflows.module';
import { AuthflowsRoutingModule } from './authflows/authflows-routing.module';

import { AppRoutingModule } from './app-routing.module';



@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    UnAuthflowsModule,
    UnAuthflowsRoutingModule,
    AuthflowsModule,
    AuthflowsRoutingModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
