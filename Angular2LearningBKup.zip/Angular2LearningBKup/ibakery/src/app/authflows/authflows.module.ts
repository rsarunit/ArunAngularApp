import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { AuthflowsRoutingModule } from './authflows-routing.module';
@NgModule({
  imports: [
    CommonModule,
    AuthflowsRoutingModule
  ],
  declarations: [HomeComponent]
})
export class AuthflowsModule { }
