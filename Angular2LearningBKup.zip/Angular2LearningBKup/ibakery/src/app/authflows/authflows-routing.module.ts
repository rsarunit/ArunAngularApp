import {NgModule} from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {HomeComponent} from './home/home.component';

const authRoutes:Routes=[
  {
    path:'home',
    component:HomeComponent
  }
];

@NgModule({
    imports:[RouterModule.forChild(authRoutes)],
    exports:[RouterModule],
    providers:[]
})

export class AuthflowsRoutingModule{

}