import { IbakeryPage } from './app.po';

describe('ibakery App', () => {
  let page: IbakeryPage;

  beforeEach(() => {
    page = new IbakeryPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
