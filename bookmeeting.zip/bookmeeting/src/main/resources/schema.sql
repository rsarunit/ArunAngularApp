--employee table drop & create query
drop table if exists `employee`;
create table `employee` (`FNAME` VARCHAR(100) NOT NULL,
`LNAME` VARCHAR(100) NOT NULL,`EMAIL` VARCHAR(100) NOT NULL, 
PRIMARY KEY (`EMAIL`));

--meeting_room table drop & create query
drop table if exists `meeting_room`;
create table `meeting_room` (`ROOM_ID` VARCHAR(10) NOT NULL,`ROOM_NAME`
VARCHAR(100) NOT NULL,`SEAT_CAPACITY` INT(4),`FLOOR_NAME` VARCHAR(100) NOT NULL,
`BUILDING_NAME` VARCHAR(100) NOT NULL, PRIMARY KEY (`ROOM_ID`));

--meeting table drop & create query
drop table if exists `meeting`;
create table `meeting` (`MEETING_ID` VARCHAR(25) NOT NULL,`MEETING_SUB` VARCHAR(200) NOT NULL,
`START_TIME` TIMESTAMP,`END_TIME` TIMESTAMP,`MROOM_ID` VARCHAR(10) NOT NULL,
`BOOKED_BY` VARCHAR(100) NOT NULL,PRIMARY KEY(`MEETING_ID`),FOREIGN KEY (`MROOM_ID`) REFERENCES `meeting_room`(`ROOM_ID`) ON DELETE CASCADE);

--attendee table drop & create query
drop table if exists `attendee`;
create table `attendee` (`REF_MEETING_ID` VARCHAR(25) NOT NULL,`ATTENDEE_EMAIL` VARCHAR(100) NOT NULL,
FOREIGN KEY (`REF_MEETING_ID`) REFERENCES `meeting`(`MEETING_ID`)ON DELETE CASCADE);