--default data for employee table
INSERT INTO `employee` values('Arun','Rajapal','rsarunit@gmail.com');
INSERT INTO `employee` values('Vinish','Vijayakumar','vinishvkumar@gmail.com');
INSERT INTO `employee` values('Vinish2','Vijayakumar','vinish_vijayakumar@zoho.com');
INSERT INTO `employee` values('Arun2','Kumar','rsarun07@gmail.com');


--default data for meeting_room table
INSERT INTO `meeting_room` values('AZ_100','Markoni',10,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_101','Kalam',5,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_102','Einstein',10,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_103','Ramanujan',5,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_104','Stevejobs',10,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_105','Jackma',5,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_106','Hensel',10,'11Floor','Neville Tower');
INSERT INTO `meeting_room` values('AZ_107','Bolt',10,'11Floor','Neville Tower');

--default data for meeting_details

--INSERT INTO `meeting` values(1,'Interview Discussion','2013-10-25 18:30:00','2013-10-25 19:30:00','AZ_100','rsarunit@gmail.com','mohamad@nodomain.com');
--INSERT INTO `meeting` values(2,'Yearly Meeting','2013-10-25 18:30:00','2013-10-25 19:30:00','AZ_101','rsarunit@gmail.com','mohamad@nodomain.com');


