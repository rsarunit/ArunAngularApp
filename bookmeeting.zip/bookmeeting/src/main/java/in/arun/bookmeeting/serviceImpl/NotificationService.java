package in.arun.bookmeeting.serviceImpl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import in.arun.bookmeeting.model.Meeting;
import in.arun.bookmeeting.model.MeetingRoom;
import in.arun.bookmeeting.service.MeetingRoomService;
import in.arun.bookmeeting.util.HtmlMeesage;

@Service
public class NotificationService {

	private JavaMailSender javaMailSender;
	@Autowired
	private MeetingRoomService meetingRoomService;
	
	@Autowired
	public NotificationService(JavaMailSender javaMailSender){
		this.javaMailSender=javaMailSender;
	}
	
	
	@Async
	public void sendNotification(Meeting meet,boolean isNew) throws MailException,InterruptedException,MessagingException{
		MeetingRoom mroom=meetingRoomService.getRoomDetails(meet.getRoomID());
		 if(mroom!=null){
			 meet.setRoomDetails(mroom.getRoomName()+"/"+mroom.getFloorName());
		 }
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, false, "utf-8");
		String htmlMsg = HtmlMeesage.getHTMLMailMessage(meet);
		mimeMessage.setContent(htmlMsg, "text/html");
		String to[]=meet.getAttendee().toArray(new String[meet.getAttendee().size()]);
		helper.setTo(to);
		helper.setReplyTo(meet.getBookedBy());
		if(isNew)
			helper.setSubject("Meeting-"+meet.getMeetingSubject());
		else
			helper.setSubject("Meeting-"+meet.getMeetingSubject()+" -Canceled..");
		helper.setFrom("astrazeneca.meeting@gmail.com");
		javaMailSender.send(mimeMessage);
		
	}
	
}
