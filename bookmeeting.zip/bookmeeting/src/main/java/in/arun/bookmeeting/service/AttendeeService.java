package in.arun.bookmeeting.service;

import java.util.List;

import in.arun.bookmeeting.model.Meeting;

public interface AttendeeService {

	public List<String> getAttendeesForMeetingID(String meetingID);
	
	public List<Meeting> updateMeetingWithAttendees(List<Meeting> meetings);
	
	public boolean attendeesBatchInsert(String meetingID,List<String> attendees);
	
	public boolean deleteMeetingAttendees(String meetingID);
	
	public boolean updateAttendeesUsingMeeting(Meeting meeting);
}
