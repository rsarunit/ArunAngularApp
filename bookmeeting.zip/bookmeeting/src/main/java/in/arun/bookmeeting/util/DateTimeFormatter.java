package in.arun.bookmeeting.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateTimeFormatter {

	private static final SimpleDateFormat dbDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private static final SimpleDateFormat uiFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
	
	private static final SimpleDateFormat calFormat=new SimpleDateFormat("E, MMM dd yyyy HH:mm");
	
	public static String getDBTimeStampString(String uiFormatString){
		try{
			Date date=uiFormat.parse(uiFormatString);
			return dbDateFormat.format(date);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public static String getTimeString(long time){
		try{
			Date date=new Date(time);
			return calFormat.format(date);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}
	
	public static String getDBTSFormat(long time){
		try{
			Date date=new Date(time);
			return dbDateFormat.format(date);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public static String getUITimeFormat(String dbFormat){
		try{
			Date date=dbDateFormat.parse(dbFormat);
			return uiFormat.format(date);
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}
	
	public static String getCalTimeString(Timestamp timestamp){
		try{
			Date date=new Date(timestamp.getTime());
			return calFormat.format(date);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Timestamp getSqlTimeStamp(String uiFormatString){
		try{
			Date date=uiFormat.parse(uiFormatString);
			return new Timestamp(date.getTime());
		}catch(Exception e){
			e.printStackTrace();
		}
		return new Timestamp(new Date().getTime());
		
	}
	
}
