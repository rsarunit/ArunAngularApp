package in.arun.bookmeeting.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import in.arun.bookmeeting.model.MeetingRoom;

public class MeetingRoomRowMapper implements RowMapper<MeetingRoom>{

	@Override
	public MeetingRoom mapRow(ResultSet rs, int count) throws SQLException {
		MeetingRoom meetingRoom=new MeetingRoom();
		meetingRoom.setRoomID(rs.getString("ROOM_ID"));
		meetingRoom.setRoomName(rs.getString("ROOM_NAME"));
		meetingRoom.setBuildingName(rs.getString("BUILDING_NAME"));
		meetingRoom.setFloorName(rs.getString("FLOOR_NAME"));
		meetingRoom.setSeatCapacity(rs.getInt("SEAT_CAPACITY"));
		return meetingRoom;
	}

}
