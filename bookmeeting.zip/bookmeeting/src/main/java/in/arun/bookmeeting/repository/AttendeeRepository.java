package in.arun.bookmeeting.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AttendeeRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<String> getAttendeeForMeetingID(String meetingID){
		String query="select ATTENDEE_EMAIL from attendee where REF_MEETING_ID ='"+meetingID+"'";
		return jdbcTemplate.queryForList(query,String.class);
	}
	
	public boolean insertAttendees(String meetingID,List<String> attendees){
		StringBuilder queryBuilder=new StringBuilder();
		queryBuilder.append("insert into attendee (REF_MEETING_ID,ATTENDEE_EMAIL) values ");
		int i=0;
		for(String attendee:attendees){
			queryBuilder.append("('"+meetingID+"','"+attendee+"')");
			if(i!=(attendees.size()-1)){
				queryBuilder.append(",");
			}
			i++;
		}
		int[] resultArray = jdbcTemplate.batchUpdate(queryBuilder.toString());
		for(int r:resultArray){
			System.out.println(r);
		}
		return true;
	}
	
	public boolean deleteMeetingAttendees(String meetingID){
		String query="delete from attendee where REF_MEETING_ID = ?";
		int result=jdbcTemplate.update(query,new Object[]{meetingID});
		if(result!=0)
			return true;
		else 
			return false;
	}
}
