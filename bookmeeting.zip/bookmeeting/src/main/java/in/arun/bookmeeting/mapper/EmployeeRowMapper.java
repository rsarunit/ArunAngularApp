/*
 * EmployeeRowMapper.java -
 * @module	in.arun.bookmeeting.rowmapper
 *
 * @purpose
 * @see 
 *
 * @author arunkumar
 *
 * @created	24-Oct-2016
 * $Id$
 * 
 * Copyright 2015-2016, rsarunit@gmail.com All rights reserved.
 */

package in.arun.bookmeeting.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import in.arun.bookmeeting.model.Employee;

public class EmployeeRowMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int count) throws SQLException {
		Employee employee=new Employee();
		employee.setFirstName(rs.getString("FNAME"));
		employee.setLastName(rs.getString("LNAME"));
		employee.setEmail(rs.getString("EMAIL"));
		return employee;
	}

}




