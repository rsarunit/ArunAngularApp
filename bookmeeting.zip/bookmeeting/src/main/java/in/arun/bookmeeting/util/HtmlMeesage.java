package in.arun.bookmeeting.util;

import in.arun.bookmeeting.model.Meeting;

public class HtmlMeesage {

	
	public static String htmlMessage="<!DOCTYPE html><html><head><link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css'><script src='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js'></script></style></head><body><div class='row'> <div class='col s12 m12'> <div class='card purple darken-1'> <div class='card-content white-text'> <span class='card-title'>Meeting @ $MEETINGROOM$</span> <p>$MEETINGSUBJECT$</p> <p>organiser : $BOOKEDBY$</p> </div> <div class='card-action'> <a href='#'>Starts @ $START$</a> <a href='#'>Ends @ $END$</a> </div> </div> </div> </div></body></html>";

    public static String getHTMLMailMessage(Meeting meet){
    	String htmlMailString=new String(htmlMessage);
    	htmlMailString=htmlMailString.replaceAll("\\$MEETINGROOM\\$", meet.getRoomDetails());
    	htmlMailString=htmlMailString.replaceAll("\\$MEETINGSUBJECT\\$", meet.getMeetingSubject());
        htmlMailString=htmlMailString.replaceAll("\\$BOOKEDBY\\$", meet.getBookedBy());
        String start= DateTimeFormatter.getTimeString(meet.getStartTime().getTime());
        String end=DateTimeFormatter.getTimeString(meet.getEndTime().getTime());
        htmlMailString=htmlMailString.replaceAll("\\$START\\$", start);
        htmlMailString=htmlMailString.replaceAll("\\$END\\$", end);
        return htmlMailString;
    }

}
