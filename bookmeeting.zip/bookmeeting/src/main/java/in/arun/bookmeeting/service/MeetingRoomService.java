package in.arun.bookmeeting.service;

import java.util.List;

import in.arun.bookmeeting.model.MeetingRoom;

public interface MeetingRoomService {

	public List<MeetingRoom> getAllRoomDetails();
	
	public MeetingRoom getRoomDetails(String meeting);
}
