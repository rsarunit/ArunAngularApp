package in.arun.bookmeeting.serviceImpl;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.arun.bookmeeting.model.Meeting;
import in.arun.bookmeeting.repository.MeetingDetailRepository;
import in.arun.bookmeeting.service.MeetingService;
import in.arun.bookmeeting.util.DateTimeFormatter;

@Service
public class MeetingServiceImpl implements MeetingService {

	@Autowired
	private MeetingDetailRepository meetingDetailRepository;
	
	
	@Override
	public List<Meeting> getAllMeetings() {
		
		
		return meetingDetailRepository.getAllMeetings();
		
	}

	@Override
	public boolean saveMeeting(Meeting meeting) {
		int result=meetingDetailRepository.saveMeeting(meeting);
		if(result!=0)
			return true;
		return false;
	}

	@Override
	public boolean deleteMeeting(String meetingID) {
		return meetingDetailRepository.deleteMeeting(meetingID);
	}

	@Override
	public boolean isMeetingOverlapped(String meetingID,String roomID, Timestamp startTime, Timestamp endTime) {
		String startTimeStr=DateTimeFormatter.getDBTSFormat(startTime.getTime());
		String endTimeStr=DateTimeFormatter.getDBTSFormat(endTime.getTime());
		return meetingDetailRepository.isMeetingOverlapped(meetingID,roomID, startTimeStr, endTimeStr);
	}

	@Override
	public boolean updateMeeting(Meeting meeting) {
		return meetingDetailRepository.updateMeeting(meeting);
	}

}
