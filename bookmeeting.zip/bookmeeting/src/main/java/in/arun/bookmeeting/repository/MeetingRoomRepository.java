package in.arun.bookmeeting.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import in.arun.bookmeeting.mapper.MeetingRoomRowMapper;
import in.arun.bookmeeting.model.MeetingRoom;

@Repository
public class MeetingRoomRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<MeetingRoom> getAllMeetingRooms(){
		return jdbcTemplate.query("select ROOM_ID,ROOM_NAME,SEAT_CAPACITY,FLOOR_NAME,BUILDING_NAME"
				+ " from meeting_room", new MeetingRoomRowMapper());
	}

	public MeetingRoom getRoomDetails(String roomID) {
		return jdbcTemplate.queryForObject("select ROOM_ID,ROOM_NAME,SEAT_CAPACITY,FLOOR_NAME,BUILDING_NAME "
				+ "from meeting_room where ROOM_ID ='"+roomID+"'",new MeetingRoomRowMapper());
	}
}
