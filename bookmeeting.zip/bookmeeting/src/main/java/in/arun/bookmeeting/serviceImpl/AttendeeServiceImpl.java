package in.arun.bookmeeting.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.arun.bookmeeting.model.Meeting;
import in.arun.bookmeeting.repository.AttendeeRepository;
import in.arun.bookmeeting.service.AttendeeService;
@Service
public class AttendeeServiceImpl implements AttendeeService {

	@Autowired
	private AttendeeRepository attendeeRepository;
	
	@Override
	public List<String> getAttendeesForMeetingID(String meetingID) {
		if(meetingID==null || meetingID.isEmpty())
			return null;
		return attendeeRepository.getAttendeeForMeetingID(meetingID);
	}

	@Override
	public boolean attendeesBatchInsert(String meetingID, List<String> attendees) {
		if(meetingID==null || meetingID.isEmpty()|| attendees==null || attendees.isEmpty())
			return false;
		return attendeeRepository.insertAttendees(meetingID, attendees);
	}

	@Override
	public List<Meeting> updateMeetingWithAttendees(List<Meeting> meetings) {
		for(Meeting meet:meetings){
			List<String> attendees=getAttendeesForMeetingID(meet.getMeetingID());
		    meet.setAttendee(attendees);
		}
		return meetings;
	}

	@Override
	public boolean deleteMeetingAttendees(String meetingID) {
		if(meetingID==null || meetingID.isEmpty())
			return false;
		return attendeeRepository.deleteMeetingAttendees(meetingID);
	}

	@Override
	public boolean updateAttendeesUsingMeeting(Meeting meeting) {
		boolean isDeleted=deleteMeetingAttendees(meeting.getMeetingID());
		if(isDeleted){
			return attendeesBatchInsert(meeting.getMeetingID(),meeting.getAttendee());
		}
		return false;
	}

	
	
}
