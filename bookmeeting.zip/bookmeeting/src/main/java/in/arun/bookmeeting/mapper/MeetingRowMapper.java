package in.arun.bookmeeting.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import in.arun.bookmeeting.model.Meeting;
import in.arun.bookmeeting.util.DateTimeFormatter;

public class MeetingRowMapper implements RowMapper<Meeting> {

	
	@Override
	public Meeting mapRow(ResultSet rs, int count) throws SQLException {
		Meeting meeting=new Meeting();
		meeting.setMeetingID(rs.getString("MEETING_ID"));
		meeting.setMeetingSubject(rs.getString("MEETING_SUB"));
		meeting.setStartTime(rs.getTimestamp("START_TIME"));
		meeting.setStartTimeStr(DateTimeFormatter.getCalTimeString(meeting.getStartTime()));
		meeting.setEndTime(rs.getTimestamp("END_TIME"));
		meeting.setEndTimeStr(DateTimeFormatter.getCalTimeString(meeting.getEndTime()));
		meeting.setBookedBy(rs.getString("BOOKED_BY"));
		meeting.setRoomID(rs.getString("MROOM_ID"));
		//meeting.setAttendee(rs.getString("ATTENDEE"));
		meeting.setRoomDetails(rs.getString("ROOM_NAME")+"/"+rs.getString("FLOOR_NAME"));
		return meeting;
	}

}
