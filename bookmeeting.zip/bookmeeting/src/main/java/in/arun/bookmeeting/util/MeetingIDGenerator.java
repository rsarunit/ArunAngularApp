/*
 * MeetingIDGenerator.java -
 * @module	in.arun.bookmeeting.util
 *
 * @purpose
 * @see 
 *
 * @author arunkumar
 *
 * @created	22-Oct-2016
 * $Id$
 * 
 * Copyright 2015-2016, rsarunit@gmail.com All rights reserved.
 */

package in.arun.bookmeeting.util;

import java.security.SecureRandom;

public class MeetingIDGenerator {

	private static SecureRandom random=new SecureRandom();
	
	
	public String getMeetingID(){
		int num = random.nextInt(100000);
		return "AZ-"+String.format("%05d", num); 
	}
	
}




