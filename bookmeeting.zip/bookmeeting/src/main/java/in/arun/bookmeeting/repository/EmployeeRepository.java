/*
 * EmployeeRepository.java -
 * @module	in.arun.bookmeeting.repo
 *
 * @purpose
 * @see 
 *
 * @author arunkumar
 *
 * @created	24-Oct-2016
 * $Id$
 * 
 * Copyright 2015-2016, rsarunit@gmail.com All rights reserved.
 */

package in.arun.bookmeeting.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import in.arun.bookmeeting.mapper.EmployeeRowMapper;
import in.arun.bookmeeting.model.Employee;

@Repository
public class EmployeeRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	
	public List<Employee> getAllEmployees() {
		return jdbcTemplate.query("select FNAME,LNAME,EMAIL from employee", new EmployeeRowMapper());
	}

	
	public List<String> getAllEmployeeEmails() {
		return jdbcTemplate.queryForList("select EMAIL from employee order by EMAIL", String.class);
	}
	

}




