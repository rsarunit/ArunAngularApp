package in.arun.bookmeeting.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.arun.bookmeeting.model.MeetingRoom;
import in.arun.bookmeeting.repository.MeetingRoomRepository;
import in.arun.bookmeeting.service.MeetingRoomService;

@Service
public class MeetingRoomServiceImpl implements MeetingRoomService {

	@Autowired
	private MeetingRoomRepository meetingRoomRepository;
	

	@Override
	public List<MeetingRoom> getAllRoomDetails() {
		return meetingRoomRepository.getAllMeetingRooms();
	}


	@Override
	public MeetingRoom getRoomDetails(String meeting) {
		
		return meetingRoomRepository.getRoomDetails(meeting);
	}
	
	

}
