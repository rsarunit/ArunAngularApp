package in.arun.bookmeeting.repository;

import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import in.arun.bookmeeting.mapper.MeetingRowMapper;
import in.arun.bookmeeting.model.Meeting;

@Repository
public class MeetingDetailRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<Meeting> getAllMeetings(){
		return jdbcTemplate.query("select m.MEETING_ID,m.MEETING_SUB,"
				+ "m.START_TIME,m.END_TIME,m.MROOM_ID,r.ROOM_NAME,r.FLOOR_NAME,m.BOOKED_BY from meeting m inner join "
				+ "meeting_room r where m.MROOM_ID = r.ROOM_ID", new MeetingRowMapper());
	}
	
	public int saveMeeting(Meeting meeting){
		String query="insert into meeting (MEETING_ID,MEETING_SUB,START_TIME,END_TIME,"
				+ "MROOM_ID,BOOKED_BY) values(?,?,?,?,?,?)";
		Object[] params=new Object[]{meeting.getMeetingID(),meeting.getMeetingSubject(),meeting.getStartTime(),meeting.getEndTime(),meeting.getRoomID(),meeting.getBookedBy()};
		int[] types=new int[]{Types.VARCHAR,Types.VARCHAR,Types.TIMESTAMP,Types.TIMESTAMP,Types.VARCHAR,Types.VARCHAR};
		return jdbcTemplate.update(query, params, types);
	}
	
	public boolean deleteMeeting(String meetingID){
		String deleteQuery="delete from meeting where MEETING_ID = ?";
		int result=jdbcTemplate.update(deleteQuery,new Object[]{meetingID});
		if(result!=0)
			return true;
		else 
			return false;
	}
	
	public boolean isMeetingOverlapped(String meetingID,String roomID, String startTime, String endTime){
		String query="select MEETING_ID,MROOM_ID,START_TIME,END_TIME from meeting where '"+endTime+"' >START_TIME AND '"+startTime+"' < END_TIME and MROOM_ID ='"+roomID+"'";
		List<Map<String, Object>> resultSet = jdbcTemplate.queryForList(query);
		if(resultSet==null || resultSet.isEmpty()){
			return false;
		}else{
			if(resultSet.size()==1){
			for(Map<String,Object> row:resultSet){
				String meetingDBID=(String)row.get("MEETING_ID");
				if(meetingDBID.equals(meetingID))
					return false;
			}
			}
			return true;
		}
	}
	
	public boolean updateMeeting(Meeting m){
		String query="update meeting set MEETING_SUB = ?,START_TIME = ?,END_TIME = ?,MROOM_ID = ?,BOOKED_BY = ? where MEETING_ID = ?";
		Object[] params=new Object[]{m.getMeetingSubject(),m.getStartTime(),m.getEndTime(),m.getRoomID(),m.getBookedBy(),m.getMeetingID()};
		int result=jdbcTemplate.update(query, params);
		if(result!=0)
			return true;
		else
			return false;
 	}
}
