package in.arun.bookmeeting.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.arun.bookmeeting.model.Employee;
import in.arun.bookmeeting.repository.EmployeeRepository;
import in.arun.bookmeeting.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.getAllEmployees();
	}


	@Override
	public List<String> getAllEmployeeEmails() {
		return employeeRepository.getAllEmployeeEmails();
	}

}
