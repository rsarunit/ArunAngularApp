package in.arun.bookmeeting.service;

import java.sql.Timestamp;
import java.util.List;

import in.arun.bookmeeting.model.Meeting;

public interface MeetingService {

	public List<Meeting> getAllMeetings();
	
	public boolean saveMeeting(Meeting meeting);
	
	public boolean updateMeeting(Meeting meeting);
	
	public boolean deleteMeeting(String meetingID);
	
	public boolean isMeetingOverlapped(String meetingID,String roomID,Timestamp startTime, Timestamp endTime);
}
