package in.arun.bookmeeting.util;


import in.arun.bookmeeting.model.Meeting;

public class ValidationUtil {

	private static final String SPL_REGEX="[^\\w\\s\\-_\\.@]";
	
	private static EmailValidator emailValidator=new EmailValidator();
	
	public static String validateMeetingObject(Meeting meeting,boolean deleteflag){
		if(meeting==null)
			return "Invalid meeting object";
		if(deleteflag){
			if(meeting.getMeetingID()==null || meeting.getMeetingID().isEmpty())
				return "Meeting ID cannot be empty";
		}
		if(meeting.getMeetingSubject()==null || meeting.getMeetingSubject().isEmpty())
		    return "Meeting Subject cannot be empty";
		meeting.setMeetingSubject(meeting.getMeetingSubject().replaceAll(SPL_REGEX, ""));
		if(meeting.getStartTime()==null || meeting.getEndTime()==null)
			return "Meeting StartTime Or EndTime cannot be empty";
		if(meeting.getStartTime().getTime() > meeting.getEndTime().getTime()){
			return "Meeting Start/End time wrong";
		}
		if(meeting.getStartTime().equals(meeting.getEndTime()))
			return "Meeting Start and End Time cannot be same";
		/*if(meeting.getAttendee()==null || meeting.getAttendee().isEmpty())
			return "Attendees cannot be empty";*/
		if(meeting.getBookedBy()==null || meeting.getBookedBy().isEmpty())
			return "Meeting host email id cannot be empty";
		if(!emailValidator.validateEmail(meeting.getBookedBy())){
			return "Invalid email entered.";
		}
		
		if(meeting.getRoomID()==null || meeting.getRoomID().isEmpty())
			return "Meeting Room cannot be empty";
		return "Success";
	}
	
	/*public static void main(String[] args) {
		Meeting meeting=new Meeting();
		meeting.setMeetingSubject("Test");
		
		Timestamp st=new Timestamp(new Date().getTime());
		
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.DAY_OF_YEAR, 1);
		Timestamp end=new Timestamp(cal.getTimeInMillis());
		
		meeting.setStartTime(end);
		meeting.setEndTime(st);
		System.out.println(st.toString()+"--"+end.toString());
		
		System.out.println(validateMeetingObject(meeting));
	}*/
	
}
