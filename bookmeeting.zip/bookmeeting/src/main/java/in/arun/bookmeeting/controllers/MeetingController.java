/*
 * MeetingController.java -
 * @module	in.booko.controller
 *
 * @purpose
 * @see 
 *
 * @author arunkumar
 *
 * @created	24-Oct-2016
 * $Id$
 * 
 * Copyright 2015-2016, rsarunit@gmail.com All rights reserved.
 */

package in.arun.bookmeeting.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.arun.bookmeeting.model.Employee;
import in.arun.bookmeeting.model.Meeting;
import in.arun.bookmeeting.model.MeetingRoom;
import in.arun.bookmeeting.service.AttendeeService;
import in.arun.bookmeeting.service.EmployeeService;
import in.arun.bookmeeting.service.MeetingRoomService;
import in.arun.bookmeeting.service.MeetingService;
import in.arun.bookmeeting.serviceImpl.NotificationService;
import in.arun.bookmeeting.util.MeetingIDGenerator;
import in.arun.bookmeeting.util.ValidationUtil;
import in.arun.bookmeeting.viewmodels.Result;

@CrossOrigin
@RestController
public class MeetingController {

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private MeetingService meetingService;
	@Autowired
	private MeetingRoomService meetingRoomService;
	@Autowired
	private AttendeeService attendeeService;
	@Autowired
	private NotificationService notificationService;
	
	
	private MeetingIDGenerator idGenerator=new MeetingIDGenerator();
	
	@RequestMapping(value="/bookMeeting",method=RequestMethod.POST,produces="application/json")
	public Result bookMeeting(@RequestBody String meetingJson){
		System.out.println(meetingJson);
		Result result=new Result("ERROR", "Unable to book meeting");
		boolean isNewMeeting=false;
		try{
			ObjectMapper mapper=new ObjectMapper();
			mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			Meeting meeting=mapper.readValue(meetingJson, Meeting.class);
			String validationMsg=ValidationUtil.validateMeetingObject(meeting,false);
			if(!validationMsg.equals("Success")){
				result.setMessage(validationMsg);
				return result;
			}
			if(meeting.getMeetingID()==null || meeting.getMeetingID().isEmpty()){
				meeting.setMeetingID(idGenerator.getMeetingID());
				isNewMeeting=true;
			}
			if(meetingService.isMeetingOverlapped(meeting.getMeetingID(),meeting.getRoomID(), meeting.getStartTime(), meeting.getEndTime())){
				result.setMessage("Meeting schedule is overlapped with other meeting");
				return result;
			}
			if(isNewMeeting){
			  if(meetingService.saveMeeting(meeting)){
				  boolean batchUpdateStatus=attendeeService.attendeesBatchInsert(meeting.getMeetingID(), meeting.getAttendee());
				  if(!batchUpdateStatus){
					  result.setMessage("Meeting booked but Attendee batch insert failed");
					  return result;
				  }
				  notificationService.sendNotification(meeting, true);
				  result.setStatus("SUCCESS");
				  result.setMessage("Meeting booked successfully");
				  return result;
			  }else{
				  result.setMessage("Unable to book meeting for meeting room "+meeting.getRoomID());
				  return result;
			  }
			}else{
				if(meetingService.updateMeeting(meeting)){
					if(!attendeeService.updateAttendeesUsingMeeting(meeting)){
						result.setMessage("Meeting updated but Attendee details update failed");
						return result;
					}
					 notificationService.sendNotification(meeting, true);
					result.setStatus("SUCCESS");
					result.setMessage("Meeting updated successfully");
					return result;
					
				}else{
					result.setMessage("Unable to update the meeting with meeting id "+meeting.getMeetingID());
					return result;
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			result.setMessage(e.getMessage());
			return result;
		}
	}
	
	
	@RequestMapping(value="/deleteMeeting",method=RequestMethod.POST,produces="application/json")
	public Result deleteMeeting(@RequestBody String meetingJson){
		Result result=new Result("ERROR", "Unable delete meeting");
		boolean deleteflag=true;
		try{
			ObjectMapper objectMapper=new ObjectMapper();
			Meeting meeting=objectMapper.readValue(meetingJson,Meeting.class);
			String validationMsg=ValidationUtil.validateMeetingObject(meeting,deleteflag);
			if(!validationMsg.equals("Success")){
				result.setMessage(validationMsg);
				return result;
			}
			if(meetingService.deleteMeeting(meeting.getMeetingID())){
				notificationService.sendNotification(meeting, false);
				result.setStatus("SUCCESS");
				result.setMessage("Meeting schedule deleted successfully");
				return result;
			}else{
				result.setMessage("Unable to delete the meeting with meeting id "+meeting.getMeetingID());
				return result;
			}
		}catch(Exception e){
			e.printStackTrace();
			result.setMessage(e.getMessage());
			return result;
		}
	}
	
	@RequestMapping(value="/getAllMeetings",produces="application/json")
	public List<Meeting> getAllMeetingDetails(){
		List<Meeting> meetings=meetingService.getAllMeetings();
		return attendeeService.updateMeetingWithAttendees(meetings);
	}
	
	@RequestMapping(value="/getAllEmployees1",produces="application/json")
	public List<Employee> getAllEmployees1(){
		return employeeService.getAllEmployees();
	}
	
	@RequestMapping(value="/getAllEmployees",produces="application/json")
	public List<String> getAllEmployees(){
		return employeeService.getAllEmployeeEmails();
	}
	
	@RequestMapping(value="/getAllRoomDetails",produces="application/json")
	public List<MeetingRoom> getAllRoomDetails(){
		return meetingRoomService.getAllRoomDetails();
	}
	
}




