package in.arun.bookmeeting.model;

public class MeetingRoom {

	private String roomID;
	private String roomName;
	private int seatCapacity;
	private String floorName;
	private String buildingName;
	
	@Override
	public String toString() {
		return "MeetingRoom [roomID=" + roomID + ", roomName=" + roomName + ", seatCapacity=" + seatCapacity
				+ ", floorName=" + floorName + ", buildingName=" + buildingName + "]";
	}
	public String getRoomID() {
		return roomID;
	}
	public void setRoomID(String roomID) {
		this.roomID = roomID;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	public String getFloorName() {
		return floorName;
	}
	public void setFloorName(String floorName) {
		this.floorName = floorName;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	
	
}
