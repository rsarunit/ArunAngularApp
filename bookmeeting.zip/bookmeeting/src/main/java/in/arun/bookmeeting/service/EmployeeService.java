package in.arun.bookmeeting.service;

import java.util.List;

import in.arun.bookmeeting.model.Employee;

public interface EmployeeService {

	public List<Employee> getAllEmployees();
	
	
	public List<String> getAllEmployeeEmails();
}
